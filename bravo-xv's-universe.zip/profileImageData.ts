export const profileImage = 'https://i.ibb.co/hFJqpJkT/upscalemedia-transformed.png';
